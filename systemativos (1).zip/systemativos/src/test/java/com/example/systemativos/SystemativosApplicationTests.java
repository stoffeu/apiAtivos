package com.example.systemativos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemativosApplicationTests {

	@Test
	void contextLoads() {
	}

}
