package com.example.systemativos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SystemativosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SystemativosApplication.class, args);
	}

}
